/* ---------- delay.h ---------- */
#ifndef SRC_DELAY_H_
#define SRC_DELAY_H_

// Include function declarations / prototypes
void SysTick_Init(void);
void delay_us(const uint32_t);

#endif /* SRC_DELAY_H_ */
